**drupal\_shanti\_kmaps**: A stand-alone module that integrated shanti Kmaps into any Drupal site. 

* **Author:** ndg8f
* **Date:** 2014-08-29

This module provides a block that displays interactive hierarchies of Knowledge Maps (Kmap) Subjects and Places to be placed in a sidebar like region. When a category is clicked on, the information about that Kmap category is displayed in the main content area.
