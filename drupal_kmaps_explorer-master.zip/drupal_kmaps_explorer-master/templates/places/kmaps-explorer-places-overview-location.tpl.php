<?php foreach($data->feature->shapes as $shape): ?>
  <div>
    <?php print $shape->display; ?>
  </div>
<?php endforeach; ?>
