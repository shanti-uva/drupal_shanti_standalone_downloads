<div class="main-overview-image">
  <img class="img-responsive" src="<?php print $url; ?>">
</div>