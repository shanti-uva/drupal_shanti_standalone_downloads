<div class="custom-inline">
  Etymology for <?php print $etymology['name']; ?>:
  <?php print $etymology['etymology_value'] ?>
</div>