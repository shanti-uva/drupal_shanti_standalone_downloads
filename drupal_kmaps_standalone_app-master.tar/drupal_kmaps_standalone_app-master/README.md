KMAPS Standalone App

A standalone app using the Drupal Apps ecosystem to add Kmaps to any Drupal 7 Site.
